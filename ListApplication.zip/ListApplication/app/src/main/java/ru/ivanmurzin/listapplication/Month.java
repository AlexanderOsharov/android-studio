package ru.ivanmurzin.listapplication;

public class Month {
    public final String name;
    public int temperature;

    public Month(String name, int temperature) {
        this.name = name;
        this.temperature = temperature;
    }
}
