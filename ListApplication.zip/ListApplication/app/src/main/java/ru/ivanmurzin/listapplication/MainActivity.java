package ru.ivanmurzin.listapplication;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;

import java.util.Arrays;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayAdapter<Month> adapter;
    Context context = this;
    private final Month[] months = new Month[5];
    Button btnAboutUs;
    Dialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        months[0] = new Month("1", 0);
        months[1] = new Month("2", 0);
        months[2] = new Month("3", 0);
        months[3] = new Month("4", 0);
        months[4] = new Month("5", 0);

        dialog = new Dialog(MainActivity.this);

        listView = findViewById(R.id.list_view);
        adapter = new MyMonthAdapter(this, months);
        listView.setAdapter(adapter);
    }

    public void showDialog(){
        Button btnClose;
        dialog.setContentView(R.layout.about_us_pop_up);
        dialog.show();
        btnClose = dialog.findViewById(R.id.close);

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }
    class MyMonthAdapter extends ArrayAdapter<Month> {

        final Month[] months;

        public MyMonthAdapter(@NonNull Context context, Month[] months) {
            super(context, R.layout.list_item);
            this.months = months;
        }

        @Override
        public int getCount() {
            return months.length;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            Month month = months[position];
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, null);
            }
            TextView title = convertView.findViewById(R.id.category);
            if (position == 0) title.setText("The beauty of nature");
            else if (position == 1 || position == 2) title.setText("Animal World");
            else if (position == 3 || position == 4) title.setText("Architectures");
            TextView text = convertView.findViewById(R.id.meme_text);
            if (position == 0) text.setText("      It's sunrise");
            else if (position == 1) text.setText("      It's a grasshopper");
            else if (position == 2) text.setText("      It's a bird");
            else if (position == 3) text.setText("      It's a fountain");
            else if (position == 4) text.setText("      This is the little prince");
            TextView Author = convertView.findViewById(R.id.author);
            Author.setText(String.valueOf("Author: Aleksander Osharov"));
            //Author.setText(String.valueOf(month.temperature));
            ImageView imageView = convertView.findViewById(R.id.image);
            if (position == 0) imageView.setImageResource(R.drawable.sunrise);
            else if (position == 1) imageView.setImageResource(R.drawable.grasshopper);
            else if (position == 2) imageView.setImageResource(R.drawable.bird);
            else if (position == 3) imageView.setImageResource(R.drawable.fountain);
            else if (position == 4) imageView.setImageResource(R.drawable.prince);
            MaterialButton like = convertView.findViewById(R.id.like);
            like.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (months[position].temperature == 0){
                        months[position].temperature = 1;
                        like.setText("1");
                        like.setBackgroundColor(ContextCompat.getColor(context, R.color.white));
                    }
                    else {
                        months[position].temperature = 0;
                        like.setText("0");
                        like.setBackgroundColor(ContextCompat.getColor(context, R.color.red));
                    }
                }
            });
            MaterialButton comment = convertView.findViewById(R.id.comment);
            comment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showDialog();
                }
            });
            MaterialButton send = convertView.findViewById(R.id.send);
            send.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(context, "The post has been sent to all WhatsApp chats", Toast.LENGTH_SHORT).show();
                }
            });
            return convertView;
        }
    }
}